"use client";

import { useState } from "react";
import { Sidebar } from "@/components/sidebar";
import { Header } from "@/components/header";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface DashboardLayoutProps {
  children: React.ReactNode;
  className?: string;
}

export function DashboardLayout({ children, className }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar */}
      <aside
        className={cn(
          "hidden md:flex md:flex-col md:fixed md:inset-y-0 z-50 bg-card border-r transition-all duration-300",
          sidebarOpen ? "md:w-64" : "md:w-16"
        )}
      >
        <div className="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto">
          <div className="flex items-center flex-shrink-0 px-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-primary-700 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-lg">I</span>
                </div>
              </div>
              {sidebarOpen && (
                <div className="ml-3">
                  <h1 className="text-xl font-bold text-primary-700">
                    Inst. System
                  </h1>
                </div>
              )}
            </div>
          </div>
          <nav className="mt-8 flex-1 px-2 space-y-1">
            <Sidebar />
          </nav>
        </div>
      </aside>

      {/* Main content */}
      <div className={cn("flex flex-col flex-1 md:pl-0", sidebarOpen ? "md:pl-64" : "md:pl-16")}>
        <Header />
        <main className="flex-1 overflow-y-auto">
          <ScrollArea className="h-full">
            <div className={cn("container mx-auto p-6", className)}>
              {children}
            </div>
          </ScrollArea>
        </main>
      </div>
    </div>
  );
}