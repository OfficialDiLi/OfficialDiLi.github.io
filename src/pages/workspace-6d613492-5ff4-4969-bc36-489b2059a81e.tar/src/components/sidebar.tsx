"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { 
  Home, 
  Users, 
  Building, 
  BookOpen, 
  Settings, 
  Menu,
  GraduationCap,
  BedDouble,
  FileText,
  Calendar,
  Bell,
  LogOut,
  User,
  ChevronDown
} from "lucide-react";

const navigation = [
  {
    name: "Dashboard",
    href: "/",
    icon: Home,
    current: true,
  },
  {
    name: "Portal",
    href: "/portal",
    icon: Users,
    current: false,
    children: [
      { name: "Student Profile", href: "/portal/student" },
      { name: "Staff Profile", href: "/portal/staff" },
      { name: "Academic Records", href: "/portal/records" },
    ],
  },
  {
    name: "Hostel Management",
    href: "/hostel",
    icon: Building,
    current: false,
    children: [
      { name: "Room Allocation", href: "/hostel/allocation" },
      { name: "Maintenance", href: "/hostel/maintenance" },
      { name: "Visitors Log", href: "/hostel/visitors" },
      { name: "Facilities", href: "/hostel/facilities" },
    ],
  },
  {
    name: "CBT System",
    href: "/cbt",
    icon: BookOpen,
    current: false,
    children: [
      { name: "Exams", href: "/cbt/exams" },
      { name: "Questions Bank", href: "/cbt/questions" },
      { name: "Results", href: "/cbt/results" },
      { name: "Schedule", href: "/cbt/schedule" },
    ],
  },
  {
    name: "Academics",
    href: "/academics",
    icon: GraduationCap,
    current: false,
    children: [
      { name: "Courses", href: "/academics/courses" },
      { name: "Timetable", href: "/academics/timetable" },
      { name: "Assignments", href: "/academics/assignments" },
      { name: "Grades", href: "/academics/grades" },
    ],
  },
  {
    name: "Facilities",
    href: "/facilities",
    icon: BedDouble,
    current: false,
    children: [
      { name: "Library", href: "/facilities/library" },
      { name: "Laboratories", href: "/facilities/labs" },
      { name: "Sports", href: "/facilities/sports" },
      { name: "Cafeteria", href: "/facilities/cafeteria" },
    ],
  },
];

interface SidebarProps {
  className?: string;
}

function SidebarContent({ className }: SidebarProps) {
  const pathname = usePathname();
  const [expandedItems, setExpandedItems] = useState<string[]>([]);

  const toggleExpanded = (itemName: string) => {
    setExpandedItems(prev =>
      prev.includes(itemName)
        ? prev.filter(item => item !== itemName)
        : [...prev, itemName]
    );
  };

  return (
    <div className={cn("pb-12", className)}>
      <div className="space-y-4 py-4">
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight text-primary-700">
            Institutions System
          </h2>
          <div className="space-y-1">
            {navigation.map((item) => {
              const isActive = pathname.startsWith(item.href);
              const isExpanded = expandedItems.includes(item.name);
              
              return (
                <div key={item.name}>
                  <Button
                    variant={isActive ? "secondary" : "ghost"}
                    className={cn(
                      "w-full justify-start text-left",
                      isActive && "bg-primary-100 text-primary-700 hover:bg-primary-200"
                    )}
                    onClick={() => item.children && toggleExpanded(item.name)}
                    asChild={!item.children}
                  >
                    {item.children ? (
                      <>
                        <item.icon className="mr-2 h-4 w-4" />
                        {item.name}
                        <ChevronDown
                          className={cn(
                            "ml-auto h-4 w-4 transition-transform",
                            isExpanded && "rotate-180"
                          )}
                        />
                      </>
                    ) : (
                      <Link href={item.href}>
                        <item.icon className="mr-2 h-4 w-4" />
                        {item.name}
                      </Link>
                    )}
                  </Button>
                  
                  {item.children && isExpanded && (
                    <div className="ml-6 mt-1 space-y-1">
                      {item.children.map((child) => {
                        const isChildActive = pathname === child.href;
                        return (
                          <Button
                            key={child.name}
                            variant={isChildActive ? "secondary" : "ghost"}
                            className={cn(
                              "w-full justify-start text-left text-sm",
                              isChildActive && "bg-accent-100 text-accent-700 hover:bg-accent-200"
                            )}
                            asChild
                          >
                            <Link href={child.href}>
                              {child.name}
                            </Link>
                          </Button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export function Sidebar({ className }: SidebarProps) {
  return (
    <div className={cn("pb-12", className)}>
      <SidebarContent />
    </div>
  );
}

export function MobileSidebar() {
  const [open, setOpen] = useState(false);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="shrink-0 md:hidden"
        >
          <Menu className="h-5 w-5" />
          <span className="sr-only">Toggle navigation menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="flex flex-col">
        <nav className="grid gap-2 text-lg font-medium">
          <SidebarContent />
        </nav>
      </SheetContent>
    </Sheet>
  );
}