export const colors = {
  // Primary Color (Main Brand Color)
  primary: {
    900: '#1a3a54',
    800: '#1f4562',
    700: '#234e70',
    600: '#2a5d87',
    500: '#306b9d',
    400: '#4a80ab',
    300: '#6d99bd',
    200: '#97b7d1',
    100: '#c1d5e4',
  },
  
  // Secondary Color (Supporting Color)
  secondary: {
    900: '#2f5c48',
    800: '#366a52',
    700: '#3e7a5e',
    600: '#478b6b',
    500: '#509b78',
    400: '#6aab8e',
    300: '#8bbfa8',
    200: '#afd4c3',
    100: '#d3e8dd',
  },
  
  // Accent Color (Gold)
  accent: {
    900: '#a9874c',
    800: '#b99454',
    700: '#cba65f',
    600: '#d2b271',
    500: '#d9be84',
    400: '#e0ca97',
    300: '#e7d6ab',
    200: '#eee2c0',
    100: '#f5eed5',
  },
  
  // Neutral Colors
  neutral: {
    black: '#121212',
    900: '#2d3748',
    800: '#4a5568',
    700: '#718096',
    600: '#a0aec0',
    500: '#cbd5e0',
    400: '#e2e8f0',
    300: '#edf2f7',
    200: '#f7fafc',
    white: '#ffffff',
  },
  
  // System Colors
  system: {
    success: '#38a169',
    warning: '#d69e2e',
    error: '#e53e3e',
    info: '#3182ce',
  }
};

// Tailwind CSS custom colors configuration
export const tailwindColors = {
  primary: colors.primary,
  secondary: colors.secondary,
  accent: colors.accent,
  neutral: colors.neutral,
  success: colors.system.success,
  warning: colors.system.warning,
  error: colors.system.error,
  info: colors.system.info,
};

// CSS Custom Properties for dynamic theming
export const cssVariables = `
  :root {
    --primary-900: ${colors.primary[900]};
    --primary-800: ${colors.primary[800]};
    --primary-700: ${colors.primary[700]};
    --primary-600: ${colors.primary[600]};
    --primary-500: ${colors.primary[500]};
    --primary-400: ${colors.primary[400]};
    --primary-300: ${colors.primary[300]};
    --primary-200: ${colors.primary[200]};
    --primary-100: ${colors.primary[100]};
    
    --secondary-900: ${colors.secondary[900]};
    --secondary-800: ${colors.secondary[800]};
    --secondary-700: ${colors.secondary[700]};
    --secondary-600: ${colors.secondary[600]};
    --secondary-500: ${colors.secondary[500]};
    --secondary-400: ${colors.secondary[400]};
    --secondary-300: ${colors.secondary[300]};
    --secondary-200: ${colors.secondary[200]};
    --secondary-100: ${colors.secondary[100]};
    
    --accent-900: ${colors.accent[900]};
    --accent-800: ${colors.accent[800]};
    --accent-700: ${colors.accent[700]};
    --accent-600: ${colors.accent[600]};
    --accent-500: ${colors.accent[500]};
    --accent-400: ${colors.accent[400]};
    --accent-300: ${colors.accent[300]};
    --accent-200: ${colors.accent[200]};
    --accent-100: ${colors.accent[100]};
    
    --neutral-black: ${colors.neutral.black};
    --neutral-900: ${colors.neutral[900]};
    --neutral-800: ${colors.neutral[800]};
    --neutral-700: ${colors.neutral[700]};
    --neutral-600: ${colors.neutral[600]};
    --neutral-500: ${colors.neutral[500]};
    --neutral-400: ${colors.neutral[400]};
    --neutral-300: ${colors.neutral[300]};
    --neutral-200: ${colors.neutral[200]};
    --neutral-white: ${colors.neutral.white};
    
    --success: ${colors.system.success};
    --warning: ${colors.system.warning};
    --error: ${colors.system.error};
    --info: ${colors.system.info};
  }
`;

// Usage guidelines
export const colorUsage = {
  primary: {
    description: 'Main brand color for primary actions and important elements',
    applications: [
      'Main buttons and CTAs',
      'Primary navigation elements',
      'Key headlines and important text',
      'Brand logos and icons'
    ]
  },
  secondary: {
    description: 'Supporting color for secondary UI elements',
    applications: [
      'Secondary buttons',
      'Supporting UI elements',
      'Section backgrounds',
      'Borders and dividers'
    ]
  },
  accent: {
    description: 'Gold accent color for highlights and premium features',
    applications: [
      'Highlights and alerts',
      'Hover states',
      'Icons and decorative elements',
      'Form focus states'
    ]
  }
};