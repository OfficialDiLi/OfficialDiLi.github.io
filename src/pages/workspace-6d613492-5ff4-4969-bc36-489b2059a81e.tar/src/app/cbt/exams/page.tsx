"use client";

import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  BookOpen, 
  Clock, 
  Users, 
  CheckCircle,
  AlertCircle,
  Calendar,
  Play,
  Edit,
  Trash2,
  Plus,
  Search,
  Filter,
  FileText,
  Award,
  TrendingUp,
  Eye
} from "lucide-react";

const exams = [
  {
    id: "1",
    title: "Data Structures Mid-term Examination",
    courseCode: "CS301",
    courseTitle: "Data Structures",
    examDate: "2024-01-20",
    startTime: "09:00 AM",
    duration: 120,
    totalMarks: 100,
    passingMarks: 40,
    totalQuestions: 50,
    registeredStudents: 45,
    status: "SCHEDULED",
    createdBy: "Dr. John Smith",
    instructions: "Read all questions carefully. No negative marking.",
  },
  {
    id: "2",
    title: "Algorithms Final Examination",
    courseCode: "CS302",
    courseTitle: "Algorithms",
    examDate: "2024-01-22",
    startTime: "02:00 PM",
    duration: 180,
    totalMarks: 150,
    passingMarks: 60,
    totalQuestions: 75,
    registeredStudents: 38,
    status: "SCHEDULED",
    createdBy: "Prof. Jane Doe",
    instructions: "Show all working steps. Partial credit will be given.",
  },
  {
    id: "3",
    title: "Database Systems Quiz",
    courseCode: "CS303",
    courseTitle: "Database Systems",
    examDate: "2024-01-18",
    startTime: "11:00 AM",
    duration: 60,
    totalMarks: 50,
    passingMarks: 25,
    totalQuestions: 25,
    registeredStudents: 42,
    status: "COMPLETED",
    createdBy: "Dr. Robert Johnson",
    instructions: "Multiple choice questions only.",
  },
];

const examResults = [
  {
    id: "1",
    examTitle: "Data Structures Mid-term Examination",
    studentName: "John Doe",
    studentId: "2024001234",
    score: 85,
    totalMarks: 100,
    percentage: 85,
    grade: "A",
    status: "PASSED",
    timeSpent: 105,
    submittedAt: "2024-01-20 10:45 AM",
  },
  {
    id: "2",
    examTitle: "Database Systems Quiz",
    studentName: "Alice Johnson",
    studentId: "2024001242",
    score: 42,
    totalMarks: 50,
    percentage: 84,
    grade: "A-",
    status: "PASSED",
    timeSpent: 55,
    submittedAt: "2024-01-18 11:55 AM",
  },
  {
    id: "3",
    examTitle: "Data Structures Mid-term Examination",
    studentName: "Bob Williams",
    studentId: "2024001243",
    score: 35,
    totalMarks: 100,
    percentage: 35,
    grade: "F",
    status: "FAILED",
    timeSpent: 120,
    submittedAt: "2024-01-20 11:00 AM",
  },
];

const questions = [
  {
    id: "1",
    examId: "1",
    questionText: "What is the time complexity of binary search?",
    questionType: "MULTIPLE_CHOICE",
    options: ["O(n)", "O(log n)", "O(n^2)", "O(1)"],
    correctAnswer: "O(log n)",
    marks: 2,
    explanation: "Binary search divides the search space in half each time, resulting in O(log n) complexity.",
  },
  {
    id: "2",
    examId: "1",
    questionText: "A stack is a LIFO data structure.",
    questionType: "TRUE_FALSE",
    correctAnswer: "True",
    marks: 1,
    explanation: "LIFO stands for Last In First Out, which is the principle of stack operations.",
  },
  {
    id: "3",
    examId: "1",
    questionText: "Explain the difference between array and linked list.",
    questionType: "SHORT_ANSWER",
    correctAnswer: "Arrays have fixed size and contiguous memory, while linked lists have dynamic size and non-contiguous memory.",
    marks: 5,
    explanation: "Arrays provide O(1) access time but require contiguous memory, while linked lists provide dynamic sizing but O(n) access time.",
  },
];

export default function CBTExams() {
  const [selectedExam, setSelectedExam] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTab, setSelectedTab] = useState("exams");

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "SCHEDULED":
        return <Badge className="bg-info-100 text-info-700 border-info-200">Scheduled</Badge>;
      case "IN_PROGRESS":
        return <Badge className="bg-warning-100 text-warning-700 border-warning-200">In Progress</Badge>;
      case "COMPLETED":
        return <Badge className="bg-success-100 text-success-700 border-success-200">Completed</Badge>;
      case "CANCELLED":
        return <Badge className="bg-error-100 text-error-700 border-error-200">Cancelled</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getGradeBadge = (grade: string) => {
    const gradeColors: { [key: string]: string } = {
      "A": "bg-success-100 text-success-700 border-success-200",
      "A-": "bg-success-100 text-success-700 border-success-200",
      "B+": "bg-primary-100 text-primary-700 border-primary-200",
      "B": "bg-primary-100 text-primary-700 border-primary-200",
      "B-": "bg-primary-100 text-primary-700 border-primary-200",
      "C+": "bg-warning-100 text-warning-700 border-warning-200",
      "C": "bg-warning-100 text-warning-700 border-warning-200",
      "C-": "bg-warning-100 text-warning-700 border-warning-200",
      "D": "bg-error-100 text-error-700 border-error-200",
      "F": "bg-error-100 text-error-700 border-error-200",
    };
    return <Badge className={gradeColors[grade] || "bg-muted-100 text-muted-700 border-muted-200"}>{grade}</Badge>;
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-primary-900">CBT Examination System</h1>
            <p className="text-primary-600">Manage computer-based tests and assessments</p>
          </div>
          <div className="flex space-x-2">
            <Button className="bg-primary-700 hover:bg-primary-800">
              <Plus className="mr-2 h-4 w-4" />
              Create Exam
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-neutral-700">Total Exams</CardTitle>
              <BookOpen className="h-4 w-4 text-primary-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-900">{exams.length}</div>
              <p className="text-xs text-muted-foreground">Active examinations</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-neutral-700">Scheduled</CardTitle>
              <Calendar className="h-4 w-4 text-info-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-900">
                {exams.filter(exam => exam.status === "SCHEDULED").length}
              </div>
              <p className="text-xs text-muted-foreground">Upcoming exams</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-neutral-700">Completed</CardTitle>
              <CheckCircle className="h-4 w-4 text-success-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-900">
                {exams.filter(exam => exam.status === "COMPLETED").length}
              </div>
              <p className="text-xs text-muted-foreground">Finished exams</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-neutral-700">Total Students</CardTitle>
              <Users className="h-4 w-4 text-accent-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-900">
                {exams.reduce((sum, exam) => sum + exam.registeredStudents, 0)}
              </div>
              <p className="text-xs text-muted-foreground">Registered students</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="exams">Exams</TabsTrigger>
            <TabsTrigger value="results">Results</TabsTrigger>
            <TabsTrigger value="questions">Questions</TabsTrigger>
          </TabsList>

          {/* Exams Tab */}
          <TabsContent value="exams" className="space-y-6">
            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle>Exam Filters</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <div>
                    <Label htmlFor="exam-filter">Exam</Label>
                    <Select value={selectedExam} onValueChange={setSelectedExam}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select exam" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Exams</SelectItem>
                        {exams.map((exam) => (
                          <SelectItem key={exam.id} value={exam.id}>
                            {exam.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="search">Search</Label>
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="search"
                        placeholder="Search exams..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <div className="flex items-end">
                    <Button variant="outline" className="w-full">
                      <Filter className="mr-2 h-4 w-4" />
                      Apply Filters
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Exams Grid */}
            <div className="grid gap-6 md:grid-cols-2">
              {exams.map((exam) => (
                <Card key={exam.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg line-clamp-2">{exam.title}</CardTitle>
                      {getStatusBadge(exam.status)}
                    </div>
                    <CardDescription>
                      {exam.courseCode} - {exam.courseTitle}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span>{exam.examDate}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{exam.startTime}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{formatDuration(exam.duration)}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span>{exam.registeredStudents} students</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Total Marks:</span>
                        <p className="font-medium">{exam.totalMarks}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Passing Marks:</span>
                        <p className="font-medium">{exam.passingMarks}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Questions:</span>
                        <p className="font-medium">{exam.totalQuestions}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Created by:</span>
                        <p className="font-medium">{exam.createdBy}</p>
                      </div>
                    </div>
                    {exam.instructions && (
                      <div>
                        <p className="text-sm font-medium mb-1">Instructions:</p>
                        <p className="text-sm text-muted-foreground line-clamp-2">{exam.instructions}</p>
                      </div>
                    )}
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Eye className="mr-1 h-3 w-3" />
                        View
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Edit className="mr-1 h-3 w-3" />
                        Edit
                      </Button>
                      {exam.status === "SCHEDULED" && (
                        <Button size="sm" className="flex-1 bg-success-600 hover:bg-success-700">
                          <Play className="mr-1 h-3 w-3" />
                          Start
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Results Tab */}
          <TabsContent value="results" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Exam Results</CardTitle>
                <CardDescription>View and analyze student performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {examResults.map((result) => (
                    <div key={result.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3">
                          <h4 className="font-medium">{result.examTitle}</h4>
                          <span className="text-sm text-muted-foreground">({result.studentId})</span>
                          {getGradeBadge(result.grade)}
                        </div>
                        <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Student:</span>
                            <p className="font-medium">{result.studentName}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Score:</span>
                            <p className="font-medium">{result.score}/{result.totalMarks}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Percentage:</span>
                            <p className="font-medium">{result.percentage}%</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Time Spent:</span>
                            <p className="font-medium">{formatDuration(result.timeSpent)}</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex space-x-2 ml-4">
                        <Button size="sm" variant="outline">
                          <FileText className="mr-1 h-3 w-3" />
                          Details
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Questions Tab */}
          <TabsContent value="questions" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Question Bank</CardTitle>
                <CardDescription>Manage exam questions and answers</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {questions.map((question) => (
                    <div key={question.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h4 className="font-medium mb-2">{question.questionText}</h4>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <span>Type: {question.questionType.replace('_', ' ')}</span>
                            <span>Marks: {question.marks}</span>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      
                      {question.options && (
                        <div className="mb-3">
                          <p className="text-sm font-medium mb-2">Options:</p>
                          <div className="grid grid-cols-2 gap-2">
                            {question.options.map((option, index) => (
                              <div key={index} className={`p-2 rounded border ${
                                option === question.correctAnswer 
                                  ? 'bg-success-50 border-success-200' 
                                  : 'bg-muted-50 border-muted-200'
                              }`}>
                                <span className="text-sm">{option}</span>
                                {option === question.correctAnswer && (
                                  <CheckCircle className="inline-block ml-2 h-3 w-3 text-success-600" />
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div>
                        <p className="text-sm font-medium mb-1">Correct Answer:</p>
                        <p className="text-sm bg-success-50 p-2 rounded border border-success-200">
                          {question.correctAnswer}
                        </p>
                      </div>
                      
                      {question.explanation && (
                        <div className="mt-3">
                          <p className="text-sm font-medium mb-1">Explanation:</p>
                          <p className="text-sm text-muted-foreground">{question.explanation}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}