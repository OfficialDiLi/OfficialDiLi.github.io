"use client";

import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Mail, 
  Phone, 
  Calendar,
  MapPin,
  BookOpen,
  Award,
  Clock,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  GraduationCap,
  Building
} from "lucide-react";

const studentData = {
  personalInfo: {
    name: "John Doe",
    email: "john.doe@institution.edu",
    phone: "+234 801 234 5678",
    studentId: "2024001234",
    department: "Computer Science",
    level: "300",
    semester: "Second Semester",
    admissionYear: "2021",
    cgpa: 3.75,
    address: "123 Student Street, Campus Area",
    emergencyContact: "+234 801 234 5679",
    dateOfBirth: "2000-05-15",
  },
  academicInfo: {
    currentCourses: [
      { code: "CS301", title: "Data Structures", credits: 3, grade: "A" },
      { code: "CS302", title: "Algorithms", credits: 3, grade: "B+" },
      { code: "CS303", title: "Database Systems", credits: 3, grade: "A-" },
      { code: "CS304", title: "Software Engineering", credits: 3, grade: "B" },
      { code: "CS305", title: "Computer Networks", credits: 3, grade: "A" },
    ],
    academicHistory: [
      { year: "2021/2022", level: "100", cgpa: 3.45, status: "Completed" },
      { year: "2022/2023", level: "200", cgpa: 3.62, status: "Completed" },
      { year: "2023/2024", level: "300", cgpa: 3.75, status: "In Progress" },
    ],
  },
  hostelInfo: {
    currentBooking: {
      hostel: "Main Hostel Block A",
      roomNumber: "305",
      floor: "3rd Floor",
      roomType: "Standard",
      checkInDate: "2024-01-15",
      status: "Active",
    },
    paymentStatus: {
      totalAmount: 150000,
      paidAmount: 150000,
      status: "Paid",
      nextPaymentDate: "2024-06-15",
    },
  },
  recentActivities: [
    {
      id: 1,
      type: "academic",
      title: "Assignment Submitted",
      description: "Data Structures Assignment 3",
      date: "2024-01-10",
      status: "completed",
    },
    {
      id: 2,
      type: "exam",
      title: "Exam Scheduled",
      description: "CS301 - Mid-term Examination",
      date: "2024-01-15",
      status: "upcoming",
    },
    {
      id: 3,
      type: "hostel",
      title: "Maintenance Request",
      description: "Room 305 - AC Repair",
      date: "2024-01-08",
      status: "in_progress",
    },
  ],
};

export default function StudentPortal() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-primary-900">Student Portal</h1>
            <p className="text-primary-600">Manage your academic and personal information</p>
          </div>
          <Button className="bg-primary-700 hover:bg-primary-800">
            <User className="mr-2 h-4 w-4" />
            Edit Profile
          </Button>
        </div>

        {/* Student Overview Card */}
        <Card className="bg-gradient-to-r from-primary-600 to-primary-700 text-white">
          <CardHeader>
            <div className="flex items-center space-x-4">
              <Avatar className="h-20 w-20 border-4 border-white/20">
                <AvatarImage src="/avatars/01.png" alt={studentData.personalInfo.name} />
                <AvatarFallback className="text-2xl bg-primary-800">
                  {studentData.personalInfo.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <CardTitle className="text-2xl">{studentData.personalInfo.name}</CardTitle>
                <CardDescription className="text-primary-100">
                  Student ID: {studentData.personalInfo.studentId} • {studentData.personalInfo.department}
                </CardDescription>
                <div className="flex items-center space-x-4 mt-2">
                  <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                    Level {studentData.personalInfo.level}
                  </Badge>
                  <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                    CGPA: {studentData.personalInfo.cgpa}
                  </Badge>
                </div>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Main Content */}
        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="personal">Personal Info</TabsTrigger>
            <TabsTrigger value="academic">Academic</TabsTrigger>
            <TabsTrigger value="hostel">Hostel</TabsTrigger>
            <TabsTrigger value="activities">Activities</TabsTrigger>
          </TabsList>

          {/* Personal Information Tab */}
          <TabsContent value="personal" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="mr-2 h-5 w-5 text-primary-600" />
                    Personal Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Full Name</label>
                      <p className="font-medium">{studentData.personalInfo.name}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Student ID</label>
                      <p className="font-medium">{studentData.personalInfo.studentId}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Date of Birth</label>
                      <p className="font-medium">{studentData.personalInfo.dateOfBirth}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Admission Year</label>
                      <p className="font-medium">{studentData.personalInfo.admissionYear}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Mail className="mr-2 h-5 w-5 text-primary-600" />
                    Contact Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Email</label>
                      <p className="font-medium">{studentData.personalInfo.email}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Phone</label>
                      <p className="font-medium">{studentData.personalInfo.phone}</p>
                    </div>
                    <div className="col-span-2">
                      <label className="text-sm font-medium text-muted-foreground">Address</label>
                      <p className="font-medium">{studentData.personalInfo.address}</p>
                    </div>
                    <div className="col-span-2">
                      <label className="text-sm font-medium text-muted-foreground">Emergency Contact</label>
                      <p className="font-medium">{studentData.personalInfo.emergencyContact}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Academic Information Tab */}
          <TabsContent value="academic" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="mr-2 h-5 w-5 text-primary-600" />
                    Current Courses
                  </CardTitle>
                  <CardDescription>
                    {studentData.personalInfo.level} Level • {studentData.personalInfo.semester}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {studentData.academicInfo.currentCourses.map((course) => (
                      <div key={course.code} className="flex items-center justify-between p-3 rounded-lg border">
                        <div>
                          <p className="font-medium">{course.title}</p>
                          <p className="text-sm text-muted-foreground">{course.code} • {course.credits} credits</p>
                        </div>
                        <Badge variant="outline" className="bg-success-50 text-success-700 border-success-200">
                          {course.grade}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="mr-2 h-5 w-5 text-primary-600" />
                    Academic History
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {studentData.academicInfo.academicHistory.map((year) => (
                      <div key={year.year} className="flex items-center justify-between p-3 rounded-lg border">
                        <div>
                          <p className="font-medium">{year.year}</p>
                          <p className="text-sm text-muted-foreground">Level {year.level}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">CGPA: {year.cgpa}</p>
                          <Badge 
                            variant={year.status === "Completed" ? "default" : "secondary"}
                            className="text-xs"
                          >
                            {year.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Hostel Information Tab */}
          <TabsContent value="hostel" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Building className="mr-2 h-5 w-5 text-primary-600" />
                    Current Accommodation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Hostel</label>
                      <p className="font-medium">{studentData.hostelInfo.currentBooking.hostel}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Room</label>
                      <p className="font-medium">{studentData.hostelInfo.currentBooking.roomNumber}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Floor</label>
                      <p className="font-medium">{studentData.hostelInfo.currentBooking.floor}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Room Type</label>
                      <p className="font-medium">{studentData.hostelInfo.currentBooking.roomType}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Check-in Date</label>
                      <p className="font-medium">{studentData.hostelInfo.currentBooking.checkInDate}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Status</label>
                      <Badge variant="outline" className="bg-success-50 text-success-700 border-success-200">
                        {studentData.hostelInfo.currentBooking.status}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="mr-2 h-5 w-5 text-primary-600" />
                    Payment Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Payment Progress</span>
                      <span className="text-sm text-muted-foreground">
                        ₦{studentData.hostelInfo.paymentStatus.paidAmount.toLocaleString()} / ₦{studentData.hostelInfo.paymentStatus.totalAmount.toLocaleString()}
                      </span>
                    </div>
                    <Progress 
                      value={(studentData.hostelInfo.paymentStatus.paidAmount / studentData.hostelInfo.paymentStatus.totalAmount) * 100} 
                      className="h-2"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Status</label>
                      <Badge variant="outline" className="bg-success-50 text-success-700 border-success-200">
                        {studentData.hostelInfo.paymentStatus.status}
                      </Badge>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Next Payment</label>
                      <p className="font-medium">{studentData.hostelInfo.paymentStatus.nextPaymentDate}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Recent Activities Tab */}
          <TabsContent value="activities" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="mr-2 h-5 w-5 text-primary-600" />
                  Recent Activities
                </CardTitle>
                <CardDescription>Your latest academic and hostel activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {studentData.recentActivities.map((activity) => (
                    <div key={activity.id} className="flex items-center space-x-4 p-4 rounded-lg border">
                      <div className="flex-shrink-0">
                        {activity.status === "completed" && (
                          <CheckCircle className="h-5 w-5 text-success-600" />
                        )}
                        {activity.status === "upcoming" && (
                          <AlertCircle className="h-5 w-5 text-warning-600" />
                        )}
                        {activity.status === "in_progress" && (
                          <Clock className="h-5 w-5 text-info-600" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-primary-900">{activity.title}</p>
                        <p className="text-sm text-muted-foreground">{activity.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">{activity.date}</p>
                      </div>
                      <Badge 
                        variant="outline" 
                        className="capitalize"
                      >
                        {activity.status.replace('_', ' ')}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}