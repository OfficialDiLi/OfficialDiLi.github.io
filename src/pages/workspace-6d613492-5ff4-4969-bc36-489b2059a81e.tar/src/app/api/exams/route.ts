import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const courseId = searchParams.get('courseId');
    const status = searchParams.get('status');
    const createdBy = searchParams.get('createdBy');

    const where: any = {};
    
    if (courseId) {
      where.courseId = courseId;
    }
    
    if (status) {
      where.status = status;
    }
    
    if (createdBy) {
      where.createdBy = createdBy;
    }

    const exams = await db.exam.findMany({
      where,
      include: {
        course: {
          select: {
            code: true,
            title: true,
          }
        },
        staff: {
          select: {
            name: true,
          }
        },
        questions: true,
        examResults: {
          select: {
            id: true,
            score: true,
            totalMarks: true,
            percentage: true,
            grade: true,
            status: true,
          }
        }
      },
      orderBy: {
        examDate: 'desc'
      }
    });

    // Add computed fields
    const examsWithStats = exams.map(exam => ({
      ...exam,
      totalQuestions: exam.questions.length,
      registeredStudents: exam.examResults.length,
      averageScore: exam.examResults.length > 0 
        ? exam.examResults.reduce((sum, result) => sum + result.percentage, 0) / exam.examResults.length
        : 0,
      passRate: exam.examResults.length > 0
        ? (exam.examResults.filter(result => result.status === 'PASSED').length / exam.examResults.length) * 100
        : 0
    }));

    return NextResponse.json(examsWithStats);
  } catch (error) {
    console.error('Error fetching exams:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const {
      title,
      description,
      courseId,
      createdBy,
      examDate,
      duration,
      totalMarks,
      passingMarks,
      instructions
    } = await request.json();

    if (!title || !courseId || !createdBy || !examDate || !duration || !totalMarks || !passingMarks) {
      return NextResponse.json(
        { error: 'Required fields are missing' },
        { status: 400 }
      );
    }

    const exam = await db.exam.create({
      data: {
        title,
        description,
        courseId,
        createdBy,
        examDate: new Date(examDate),
        duration,
        totalMarks,
        passingMarks,
        instructions,
      },
      include: {
        course: {
          select: {
            code: true,
            title: true,
          }
        },
        staff: {
          select: {
            name: true,
          }
        }
      }
    });

    return NextResponse.json({
      message: 'Exam created successfully',
      exam,
    });
  } catch (error) {
    console.error('Error creating exam:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}