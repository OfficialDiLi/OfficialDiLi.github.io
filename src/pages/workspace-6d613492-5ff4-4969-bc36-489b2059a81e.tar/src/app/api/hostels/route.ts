import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const gender = searchParams.get('gender');
    const isActive = searchParams.get('isActive');

    const where: any = {};
    
    if (gender) {
      where.gender = gender;
    }
    
    if (isActive !== null) {
      where.isActive = isActive === 'true';
    }

    const hostels = await db.hostel.findMany({
      where,
      include: {
        rooms: {
          include: {
            hostelBookings: {
              where: { status: 'ACTIVE' }
            }
          }
        }
      },
      orderBy: {
        name: 'asc'
      }
    });

    // Calculate occupancy for each hostel
    const hostelsWithOccupancy = hostels.map(hostel => ({
      ...hostel,
      totalCapacity: hostel.rooms.reduce((sum, room) => sum + room.capacity, 0),
      currentOccupancy: hostel.rooms.reduce((sum, room) => 
        sum + room.hostelBookings.length, 0
      ),
      availableRooms: hostel.rooms.filter(room => 
        room.hostelBookings.length < room.capacity
      ).length
    }));

    return NextResponse.json(hostelsWithOccupancy);
  } catch (error) {
    console.error('Error fetching hostels:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const {
      name,
      description,
      gender,
      totalRooms,
      capacity,
      wardenName,
      wardenPhone,
      address
    } = await request.json();

    if (!name || !gender || !totalRooms || !capacity) {
      return NextResponse.json(
        { error: 'Required fields are missing' },
        { status: 400 }
      );
    }

    const hostel = await db.hostel.create({
      data: {
        name,
        description,
        gender,
        totalRooms,
        capacity,
        wardenName,
        wardenPhone,
        address,
      },
    });

    return NextResponse.json({
      message: 'Hostel created successfully',
      hostel,
    });
  } catch (error) {
    console.error('Error creating hostel:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}