"use client";

import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Users, 
  Building, 
  BookOpen, 
  TrendingUp,
  Calendar,
  AlertCircle,
  CheckCircle,
  Clock
} from "lucide-react";

const stats = [
  {
    title: "Total Students",
    value: "1,234",
    change: "+12%",
    changeType: "positive",
    icon: Users,
    color: "text-primary-600",
    bgColor: "bg-primary-100",
  },
  {
    title: "Hostel Occupancy",
    value: "89%",
    change: "+5%",
    changeType: "positive",
    icon: Building,
    color: "text-secondary-600",
    bgColor: "bg-secondary-100",
  },
  {
    title: "Active Exams",
    value: "8",
    change: "-2",
    changeType: "negative",
    icon: BookOpen,
    color: "text-accent-600",
    bgColor: "bg-accent-100",
  },
  {
    title: "System Performance",
    value: "98.5%",
    change: "+0.5%",
    changeType: "positive",
    icon: TrendingUp,
    color: "text-success-600",
    bgColor: "bg-success-100",
  },
];

const recentActivities = [
  {
    id: 1,
    type: "room_allocation",
    message: "Room 305 allocated to John Smith",
    time: "2 hours ago",
    status: "completed",
  },
  {
    id: 2,
    type: "exam_scheduled",
    message: "Mathematics exam scheduled for tomorrow",
    time: "3 hours ago",
    status: "pending",
  },
  {
    id: 3,
    type: "maintenance",
    message: "Maintenance request for Room 201",
    time: "5 hours ago",
    status: "in_progress",
  },
  {
    id: 4,
    type: "portal_update",
    message: "Student profile updated",
    time: "1 day ago",
    status: "completed",
  },
];

const upcomingEvents = [
  {
    id: 1,
    title: "CBT Examination - Mathematics",
    date: "2024-01-15",
    time: "2:00 PM",
    type: "exam",
  },
  {
    id: 2,
    title: "Hostel Inspection",
    date: "2024-01-16",
    time: "10:00 AM",
    type: "inspection",
  },
  {
    id: 3,
    title: "Staff Meeting",
    date: "2024-01-17",
    time: "3:00 PM",
    type: "meeting",
  },
];

export default function Home() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-primary-900">Dashboard</h1>
          <p className="text-primary-600">Welcome to the Institutions Management System</p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-neutral-700">
                  {stat.title}
                </CardTitle>
                <div className={`p-2 rounded-full ${stat.bgColor}`}>
                  <stat.icon className={`h-4 w-4 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary-900">{stat.value}</div>
                <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                  <span
                    className={
                      stat.changeType === "positive" ? "text-success-600" : "text-error-600"
                    }
                  >
                    {stat.change}
                  </span>
                  <span>from last month</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {/* Recent Activities */}
          <Card className="col-span-2">
            <CardHeader>
              <CardTitle className="text-primary-900">Recent Activities</CardTitle>
              <CardDescription>Latest system activities and updates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-center space-x-4 p-3 rounded-lg hover:bg-neutral-50">
                    <div className="flex-shrink-0">
                      {activity.status === "completed" && (
                        <CheckCircle className="h-5 w-5 text-success-600" />
                      )}
                      {activity.status === "pending" && (
                        <Clock className="h-5 w-5 text-warning-600" />
                      )}
                      {activity.status === "in_progress" && (
                        <AlertCircle className="h-5 w-5 text-info-600" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-primary-900 truncate">
                        {activity.message}
                      </p>
                      <p className="text-sm text-muted-foreground">{activity.time}</p>
                    </div>
                    <Badge variant="outline" className="capitalize">
                      {activity.status.replace("_", " ")}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Events */}
          <Card>
            <CardHeader>
              <CardTitle className="text-primary-900">Upcoming Events</CardTitle>
              <CardDescription>Scheduled activities and deadlines</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingEvents.map((event) => (
                  <div key={event.id} className="p-3 rounded-lg border border-neutral-200">
                    <div className="flex items-start space-x-3">
                      <Calendar className="h-5 w-5 text-primary-600 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-primary-900 truncate">
                          {event.title}
                        </p>
                        <div className="flex items-center space-x-2 mt-1">
                          <p className="text-xs text-muted-foreground">{event.date}</p>
                          <span className="text-xs text-muted-foreground">•</span>
                          <p className="text-xs text-muted-foreground">{event.time}</p>
                        </div>
                        <Badge 
                          variant="secondary" 
                          className="mt-2 text-xs capitalize"
                        >
                          {event.type}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-primary-900">Quick Actions</CardTitle>
            <CardDescription>Frequently used system functions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Button 
                variant="outline" 
                className="h-20 flex-col space-y-2 hover:bg-primary-50 hover:border-primary-300"
              >
                <Users className="h-6 w-6 text-primary-600" />
                <span className="text-sm">Student Portal</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-20 flex-col space-y-2 hover:bg-secondary-50 hover:border-secondary-300"
              >
                <Building className="h-6 w-6 text-secondary-600" />
                <span className="text-sm">Hostel Management</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-20 flex-col space-y-2 hover:bg-accent-50 hover:border-accent-300"
              >
                <BookOpen className="h-6 w-6 text-accent-600" />
                <span className="text-sm">CBT System</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-20 flex-col space-y-2 hover:bg-success-50 hover:border-success-300"
              >
                <Calendar className="h-6 w-6 text-success-600" />
                <span className="text-sm">Schedule</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle className="text-primary-900">System Status</CardTitle>
            <CardDescription>Overall system health and performance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Portal System</span>
                  <span className="text-success-600">Operational</span>
                </div>
                <Progress value={100} className="h-2" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Hostel Management</span>
                  <span className="text-success-600">Operational</span>
                </div>
                <Progress value={98} className="h-2" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">CBT System</span>
                  <span className="text-warning-600">Maintenance</span>
                </div>
                <Progress value={75} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}