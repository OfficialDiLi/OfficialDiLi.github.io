"use client";

import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Building, 
  Users, 
  BedDouble, 
  Search,
  Filter,
  Plus,
  Eye,
  Edit,
  Trash2,
  MapPin,
  Calendar,
  CheckCircle,
  AlertCircle,
  Clock
} from "lucide-react";

const hostels = [
  {
    id: "1",
    name: "Main Hostel Block A",
    gender: "MALE",
    totalRooms: 100,
    capacity: 400,
    currentOccupancy: 350,
    wardenName: "Mr. Johnson",
    wardenPhone: "+234 801 234 5678",
    address: "Main Campus, Block A",
    isActive: true,
  },
  {
    id: "2",
    name: "Female Hostel Block B",
    gender: "FEMALE",
    totalRooms: 80,
    capacity: 320,
    currentOccupancy: 280,
    wardenName: "Mrs. Smith",
    wardenPhone: "+234 801 234 5679",
    address: "Main Campus, Block B",
    isActive: true,
  },
  {
    id: "3",
    name: "Postgraduate Hostel",
    gender: "MIXED",
    totalRooms: 50,
    capacity: 200,
    currentOccupancy: 150,
    wardenName: "Dr. Brown",
    wardenPhone: "+234 801 234 5680",
    address: "Postgraduate Campus",
    isActive: true,
  },
];

const rooms = [
  {
    id: "1",
    hostelId: "1",
    roomNumber: "101",
    floor: 1,
    capacity: 4,
    currentOccupancy: 4,
    roomType: "STANDARD",
    amenities: ["Bed", "Study Table", "Wardrobe", "Fan"],
    isActive: true,
    occupants: [
      { name: "John Doe", studentId: "2024001234" },
      { name: "James Smith", studentId: "2024001235" },
      { name: "Robert Johnson", studentId: "2024001236" },
      { name: "Michael Brown", studentId: "2024001237" },
    ],
  },
  {
    id: "2",
    hostelId: "1",
    roomNumber: "102",
    floor: 1,
    capacity: 4,
    currentOccupancy: 3,
    roomType: "STANDARD",
    amenities: ["Bed", "Study Table", "Wardrobe", "Fan"],
    isActive: true,
    occupants: [
      { name: "William Davis", studentId: "2024001238" },
      { name: "Richard Miller", studentId: "2024001239" },
      { name: "Charles Wilson", studentId: "2024001240" },
    ],
  },
  {
    id: "3",
    hostelId: "1",
    roomNumber: "201",
    floor: 2,
    capacity: 2,
    currentOccupancy: 1,
    roomType: "DELUXE",
    amenities: ["Bed", "Study Table", "Wardrobe", "AC", "Private Bathroom"],
    isActive: true,
    occupants: [
      { name: "Joseph Moore", studentId: "2024001241" },
    ],
  },
];

const bookingRequests = [
  {
    id: "1",
    studentName: "Alice Johnson",
    studentId: "2024001242",
    hostelName: "Female Hostel Block B",
    roomType: "STANDARD",
    bookingDate: "2024-01-10",
    status: "PENDING",
    duration: "1 Year",
  },
  {
    id: "2",
    studentName: "Bob Williams",
    studentId: "2024001243",
    hostelName: "Main Hostel Block A",
    roomType: "DELUXE",
    bookingDate: "2024-01-09",
    status: "APPROVED",
    duration: "1 Year",
  },
  {
    id: "3",
    studentName: "Carol Davis",
    studentId: "2024001244",
    hostelName: "Postgraduate Hostel",
    roomType: "STANDARD",
    bookingDate: "2024-01-08",
    status: "REJECTED",
    duration: "6 Months",
  },
];

export default function HostelAllocation() {
  const [selectedHostel, setSelectedHostel] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTab, setSelectedTab] = useState("hostels");

  const filteredRooms = rooms.filter(room => {
    const matchesHostel = !selectedHostel || room.hostelId === selectedHostel;
    const matchesSearch = !searchTerm || 
      room.roomNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      room.roomType.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesHostel && matchesSearch;
  });

  const getOccupancyPercentage = (current: number, capacity: number) => {
    return (current / capacity) * 100;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "APPROVED":
        return <Badge className="bg-success-100 text-success-700 border-success-200">Approved</Badge>;
      case "PENDING":
        return <Badge className="bg-warning-100 text-warning-700 border-warning-200">Pending</Badge>;
      case "REJECTED":
        return <Badge className="bg-error-100 text-error-700 border-error-200">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-primary-900">Hostel Management</h1>
            <p className="text-primary-600">Manage hostel allocations and room assignments</p>
          </div>
          <div className="flex space-x-2">
            <Button className="bg-primary-700 hover:bg-primary-800">
              <Plus className="mr-2 h-4 w-4" />
              New Booking
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-neutral-700">Total Hostels</CardTitle>
              <Building className="h-4 w-4 text-primary-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-900">{hostels.length}</div>
              <p className="text-xs text-muted-foreground">Active accommodations</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-neutral-700">Total Rooms</CardTitle>
              <BedDouble className="h-4 w-4 text-secondary-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-900">
                {hostels.reduce((sum, hostel) => sum + hostel.totalRooms, 0)}
              </div>
              <p className="text-xs text-muted-foreground">Available rooms</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-neutral-700">Occupancy Rate</CardTitle>
              <Users className="h-4 w-4 text-accent-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-900">
                {Math.round(
                  hostels.reduce((sum, hostel) => sum + hostel.currentOccupancy, 0) /
                  hostels.reduce((sum, hostel) => sum + hostel.capacity, 0) * 100
                )}%
              </div>
              <p className="text-xs text-muted-foreground">Average occupancy</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-neutral-700">Pending Requests</CardTitle>
              <Clock className="h-4 w-4 text-warning-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-900">
                {bookingRequests.filter(req => req.status === "PENDING").length}
              </div>
              <p className="text-xs text-muted-foreground">Awaiting approval</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="hostels">Hostels</TabsTrigger>
            <TabsTrigger value="rooms">Rooms</TabsTrigger>
            <TabsTrigger value="bookings">Bookings</TabsTrigger>
          </TabsList>

          {/* Hostels Tab */}
          <TabsContent value="hostels" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {hostels.map((hostel) => (
                <Card key={hostel.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{hostel.name}</CardTitle>
                      <Badge variant="outline" className="bg-primary-50 text-primary-700 border-primary-200">
                        {hostel.gender}
                      </Badge>
                    </div>
                    <CardDescription className="flex items-center">
                      <MapPin className="mr-1 h-3 w-3" />
                      {hostel.address}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Occupancy</span>
                        <span>{hostel.currentOccupancy}/{hostel.capacity}</span>
                      </div>
                      <Progress 
                        value={getOccupancyPercentage(hostel.currentOccupancy, hostel.capacity)} 
                        className="h-2"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Total Rooms:</span>
                        <p className="font-medium">{hostel.totalRooms}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Occupancy Rate:</span>
                        <p className="font-medium">
                          {Math.round(getOccupancyPercentage(hostel.currentOccupancy, hostel.capacity))}%
                        </p>
                      </div>
                    </div>
                    <div className="border-t pt-4">
                      <p className="text-sm text-muted-foreground">Warden: {hostel.wardenName}</p>
                      <p className="text-sm text-muted-foreground">Contact: {hostel.wardenPhone}</p>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Eye className="mr-1 h-3 w-3" />
                        View
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Edit className="mr-1 h-3 w-3" />
                        Edit
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Rooms Tab */}
          <TabsContent value="rooms" className="space-y-6">
            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle>Room Filters</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <div>
                    <Label htmlFor="hostel-filter">Hostel</Label>
                    <Select value={selectedHostel} onValueChange={setSelectedHostel}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select hostel" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Hostels</SelectItem>
                        {hostels.map((hostel) => (
                          <SelectItem key={hostel.id} value={hostel.id}>
                            {hostel.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="search">Search</Label>
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="search"
                        placeholder="Search rooms..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <div className="flex items-end">
                    <Button variant="outline" className="w-full">
                      <Filter className="mr-2 h-4 w-4" />
                      Apply Filters
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Rooms Grid */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredRooms.map((room) => (
                <Card key={room.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">Room {room.roomNumber}</CardTitle>
                      <Badge variant="outline" className="bg-secondary-50 text-secondary-700 border-secondary-200">
                        {room.roomType}
                      </Badge>
                    </div>
                    <CardDescription>Floor {room.floor}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Occupancy</span>
                        <span>{room.currentOccupancy}/{room.capacity}</span>
                      </div>
                      <Progress 
                        value={getOccupancyPercentage(room.currentOccupancy, room.capacity)} 
                        className="h-2"
                      />
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-2">Amenities:</p>
                      <div className="flex flex-wrap gap-1">
                        {room.amenities.map((amenity, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {amenity}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    {room.occupants.length > 0 && (
                      <div>
                        <p className="text-sm font-medium mb-2">Occupants:</p>
                        <div className="space-y-1">
                          {room.occupants.map((occupant, index) => (
                            <div key={index} className="text-xs text-muted-foreground">
                              {occupant.name} ({occupant.studentId})
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Eye className="mr-1 h-3 w-3" />
                        View
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1"
                        disabled={room.currentOccupancy >= room.capacity}
                      >
                        <Plus className="mr-1 h-3 w-3" />
                        Assign
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Bookings Tab */}
          <TabsContent value="bookings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Booking Requests</CardTitle>
                <CardDescription>Manage student hostel booking requests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {bookingRequests.map((booking) => (
                    <div key={booking.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3">
                          <h4 className="font-medium">{booking.studentName}</h4>
                          <span className="text-sm text-muted-foreground">({booking.studentId})</span>
                          {getStatusBadge(booking.status)}
                        </div>
                        <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Hostel:</span>
                            <p className="font-medium">{booking.hostelName}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Room Type:</span>
                            <p className="font-medium">{booking.roomType}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Duration:</span>
                            <p className="font-medium">{booking.duration}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Applied:</span>
                            <p className="font-medium">{booking.bookingDate}</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex space-x-2 ml-4">
                        {booking.status === "PENDING" && (
                          <>
                            <Button size="sm" className="bg-success-600 hover:bg-success-700">
                              <CheckCircle className="mr-1 h-3 w-3" />
                              Approve
                            </Button>
                            <Button size="sm" variant="outline" className="text-error-600 hover:text-error-700">
                              <AlertCircle className="mr-1 h-3 w-3" />
                              Reject
                            </Button>
                          </>
                        )}
                        <Button size="sm" variant="outline">
                          <Eye className="mr-1 h-3 w-3" />
                          View
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}